#include <iostream>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

struct Task {
    string description;
    int day;
};

class MonthlyCalendar {
private:
    vector<vector<Task>> calendar;

public:
    MonthlyCalendar() {
        calendar.resize(31);
    }

    void addTask(int day, const string& description) {
        if (day >= 1 && day <= 31) {
            calendar[day - 1].push_back({description, day});
            cout << "Task added successfully!\n";
        } else {
            cout << "Invalid day. Please enter a day between 1 and 31.\n";
        }
    }

    void displayCalendar() {
        cout << "Monthly Calendar:\n";
        cout << "-----------------\n";
        for (int i = 0; i < calendar.size(); ++i) {
            if (!calendar[i].empty()) {
                cout << "Day " << setw(2) << i + 1 << ": ";
                for (const auto& task : calendar[i]) {
                    cout << task.description << " ";
                }
                cout << "\n";
            }
        }
        cout << "-----------------\n";
    }
};

int main() {
    MonthlyCalendar calendar;

    int choice;
    do {
        cout << "To-Do App Menu:\n";
        cout << "1. Add Task\n";
        cout << "2. Display Calendar\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                int day;
                string description;

                cout << "Enter the day (1-31): ";
                cin >> day;

                cin.ignore();

                cout << "Enter task description: ";
                getline(cin, description);

                calendar.addTask(day, description);
                break;
            }
            case 2:
                calendar.displayCalendar();
                break;
            case 3:
                cout << "Exiting the To-Do App. Goodbye!\n";
                break;
            default:
                cout << "Invalid choice. Please enter a valid option.\n";
        }
    } while (choice != 3);

    return 0;
}
