import java.util.Scanner;

public class TypingSpeedTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Provide a sentence for typing
        String sentence = "The quick brown fox jumps over the lazy dog.";

        // Display the sentence to the user
        System.out.println("Type the following sentence:");
        System.out.println(sentence);

        // Record the start time
        long startTime = System.currentTimeMillis();

        // Read the user's input
        String userTyped = scanner.nextLine();

        // Record the end time
        long endTime = System.currentTimeMillis();

        // Calculate the time taken in seconds
        double timeTakenSeconds = (endTime - startTime) / 1000.0;

        // Count the number of words in the provided sentence
        int wordCount = sentence.split("\\s+").length;

        // Count the number of correct words typed by the user
        int correctWords = countCorrectWords(sentence, userTyped);

        // Calculate typing speed in words per minute (WPM)
        int wpm = (int) ((correctWords / timeTakenSeconds) * 60);

        // Display the result
        System.out.println("\nTyping Speed Test Result:");
        System.out.println("Time taken: " + timeTakenSeconds + " seconds");
        System.out.println("Correct words: " + correctWords);
        System.out.println("Typing speed: " + wpm + " WPM");

        scanner.close();
    }

    // Count the number of correct words typed by the user
    private static int countCorrectWords(String original, String typed) {
        String[] originalWords = original.split("\\s+");
        String[] typedWords = typed.split("\\s+");

        int correctWords = 0;
        int minLength = Math.min(originalWords.length, typedWords.length);

        for (int i = 0; i < minLength; i++) {
            if (originalWords[i].equals(typedWords[i])) {
                correctWords++;
            }
        }

        return correctWords;
    }
}
