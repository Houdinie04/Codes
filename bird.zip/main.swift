import PlaygroundSupport
import SwiftUI

struct ContentView: View {
    @State private var birdPosition = 150.0
    @State private var obstaclePosition = 400.0
    @State private var score = 0

    var body: some View {
        VStack {
            Text("Flappy Bird Game")
                .font(.title)
                .padding()
            Spacer()
            Image(systemName: "bird.fill")
                .foregroundColor(.blue)
                .offset(y: birdPosition)
                .frame(width: 50, height: 50)
            Spacer()
            Text("Score: \(score)")
                .font(.headline)
                .padding()
        }
        .onTapGesture {
            self.jump()
        }
        .onAppear {
            self.startGame()
        }
        .onReceive(Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()) { _ in
            self.moveObstacle()
        }
    }

    func startGame() {
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            self.generateObstacle()
        }
    }

    func jump() {
        withAnimation {
            birdPosition -= 50
        }
    }

    func generateObstacle() {
        withAnimation {
            obstaclePosition -= 50
            if obstaclePosition <= -50 {
                obstaclePosition = 400
                score += 1
            }
        }
    }

    func moveObstacle() {
        withAnimation {
            obstaclePosition -= 10
            if obstaclePosition <= -50 {
                obstaclePosition = 400
                score += 1
            }
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())
