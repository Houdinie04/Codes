#include <iostream>
#include <string>

using namespace std;

class ExpenseTracker {
private:
    double income;
    double remainingBalance;

public:
    ExpenseTracker() : income(0), remainingBalance(0) {}

    void setIncome() {
        do {
            cout << "Enter your monthly income: $";
            cin >> income;

            if (income <= 0) {
                cout << "Invalid input. Please enter a number greater than 0.\n";
            }

        } while (income <= 0);

        remainingBalance = income;
    }

    void addExpense(const string& category) {
        double cost;
        cout << "Enter the cost of " << category << ": $";
        cin >> cost;

        if (cost <= remainingBalance) {
            remainingBalance -= cost;
            cout << "Expense added successfully!\n";
        } else {
            cout << "Insufficient funds. Please enter a valid cost.\n";
        }

        if (remainingBalance <= 100) {
            cout << "WARNING: Your remaining balance is getting low. Consider managing your expenses carefully.\n";
        }
    }

    void displayRemainingBalance() {
        cout << "\nRemaining Balance: $" << remainingBalance << "\n";
    }
};

int main() {
    ExpenseTracker tracker;

    cout << "Welcome to the Expense Tracker!\n";
    tracker.setIncome();

    int choice;
    do {
        cout << "\nExpense Categories:\n";
        cout << "1. Transportation\n";
        cout << "2. Living Expenses\n";
        cout << "3. Food\n";
        cout << "4. Other\n";
        cout << "5. Display Remaining Balance\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                tracker.addExpense("Transportation");
                break;
            case 2:
                tracker.addExpense("Living Expenses");
                break;
            case 3:
                tracker.addExpense("Food");
                break;
            case 4:
                tracker.addExpense("Other");
                break;
            case 5:
                tracker.displayRemainingBalance();
                break;
            case 6:
                cout << "Exiting the Expense Tracker. Goodbye!\n";
                break;
            default:
                cout << "Invalid choice. Please enter a valid option.\n";
        }
    } while (choice != 6);

    return 0;
}
