#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>

using namespace std;

const string FILENAME = "passwords.txt";

class PasswordManager {
private:
    struct Credential {
        string username;
        string password;
    };

    unordered_map<string, Credential> credentials;
    string currentUsername;

public:
    PasswordManager() : currentUsername("") {}

    void loadCredentials() {
        ifstream file(FILENAME);
        if (file.is_open()) {
            string username, website, password;
            while (file >> username >> website >> password) {
                credentials[username + "_" + website] = {username, password};
            }
            file.close();
        }
    }

    void saveCredentials() {
        ofstream file(FILENAME);
        if (file.is_open()) {
            for (const auto& entry : credentials) {
                file << entry.second.username << " " << entry.first.substr(entry.second.username.length() + 1) << " " << entry.second.password << "\n";
            }
            file.close();
        }
    }

    void initializeCredentials() {
        string username, password;
        cout << "Welcome! Let's set up your initial username and password.\n";
        cout << "Enter your username: ";
        cin >> username;
        cout << "Enter your password: ";
        cin >> password;

        currentUsername = username;
        credentials[currentUsername + "_init"] = {username, password};
        saveCredentials();
        cout << "Initialization successful!\n";
    }

    bool login(const string& username, const string& password) {
        auto it = credentials.find(username + "_init");
        if (it != credentials.end() && it->second.password == password) {
            cout << "Login successful!\n";
            currentUsername = username;
            return true;
        } else {
            cout << "Invalid username or password. Login failed.\n";
            return false;
        }
    }

    void addPassword(const string& website, const string& password) {
        string key = currentUsername + "_" + website;
        credentials[key] = {currentUsername, password};
        saveCredentials();
        cout << "Password for " << website << " added successfully!\n";
    }

    void displayPasswords() {
        cout << "Your saved passwords:\n";
        cout << "----------------------\n";
        cout << "Website\t\tUsername\tPassword\n";
        cout << "----------------------\n";
        for (const auto& entry : credentials) {
            cout << entry.first.substr(entry.second.username.length() + 1) << "\t\t" << entry.second.username << "\t\t" << entry.second.password << "\n";
        }
        cout << "----------------------\n";
    }
};

int main() {
    PasswordManager manager;
    manager.loadCredentials();

    // Check if the program is run for the first time
    if (manager.login("init", "init")) {
        manager.initializeCredentials();
    }

    string username, password;

    // Login
    do {
        cout << "Enter your username: ";
        cin >> username;
        cout << "Enter your password: ";
        cin >> password;
    } while (!manager.login(username, password));

    int choice;

    do {
        cout << "\nPassword Manager Menu:\n";
        cout << "1. Add Password\n";
        cout << "2. Display Passwords\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                string website, newPassword;
                cout << "Enter the website: ";
                cin >> website;
                cout << "Enter the password: ";
                cin >> newPassword;
                manager.addPassword(website, newPassword);
                break;
            }
            case 2:
                manager.displayPasswords();
                break;
            case 3:
                cout << "Exiting the Password Manager. Goodbye!\n";
                break;
            default:
                cout << "Invalid choice. Please enter a valid option.\n";
        }

    } while (choice != 3);

    return 0;
}
